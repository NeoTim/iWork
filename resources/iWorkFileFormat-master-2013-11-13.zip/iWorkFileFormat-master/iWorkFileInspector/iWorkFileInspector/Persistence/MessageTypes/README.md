These .json files were created from Keynote 6.0, Pages 5.0 and Numbers 3.0. They were created by attaching to the running applications using F-Script and evaluating this expression:

	> TSPRegistry sharedRegistry

The resulting output was then manually cleaned up and organized.