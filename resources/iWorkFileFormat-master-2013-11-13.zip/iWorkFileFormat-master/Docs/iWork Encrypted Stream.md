# iWork '13 Encrypted Stream
Description forthcoming. For now see [NSData+IWCrypto.m](../iWorkFileInspector/iWorkFileInspector/Crypto/NSData+IWCrypto.m) and [IWPasswordVerifier.m](../iWorkFileInspector/iWorkFileInspector/Crypto/IWPasswordVerifier.m).
