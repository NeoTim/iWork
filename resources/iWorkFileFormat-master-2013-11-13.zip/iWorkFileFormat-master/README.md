iWork '13 File Format
=====================
This project aims to demystify the file format used by Apple's iWork '13 apps.

A [description](Docs/index.md) of the format is available, as is a [sample project](iWorkFileInspector/).

License
-------
This project is released under the MIT license. See
[LICENSE](LICENSE).